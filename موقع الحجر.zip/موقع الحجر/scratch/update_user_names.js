const { loadDb, saveDb, transaction } = require('../server/db');

transaction((db) => {
  const admin = db.users.find((u) => u.username === 'admin');
  if (admin) {
    admin.full_name = 'ماجد محسن الشهري (المدير العام)';
  }

  const staff = db.users.find((u) => u.username === 'staff');
  if (staff) {
    staff.full_name = 'فهد الغامدي (مشرف الدخول والتفويج)';
  }
});

console.log('Users updated successfully:');
const db = loadDb();
db.users.forEach((u) => console.log(`- ${u.username}: ${u.full_name}`));
