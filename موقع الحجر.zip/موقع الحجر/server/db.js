const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');
const BACKUP_FILE = path.join(DATA_DIR, 'database.backup.json');

// تأكد من وجود مجلد البيانات
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// الهيكل الأساسي للجداول
const DEFAULT_SCHEMA = {
  users: [],
  appointments: [],
  bookings: [],
  qr_tokens: [],
  audit_logs: [],
  settings: {
    platform_name: 'منصة تنظيم مواعيد دخول الحِجر',
    platform_subtitle: 'نظام حجز إلكتروني مستقل لتنظيم مواعيد الزيارة بسلاسة وأمان',
    disclaimer: 'تنبيه تنظيمي: هذه منصة حجز مستقلة لتنظيم المواعيد والتفويج وليست جهة حكومية رسمية، ولا تُعد بديلاً عن التصاريح الرسمية المعتمدة من الجهات المختصة.',
    contact_phone: '920000000',
    contact_email: 'support@alhijr-booking.local',
    max_persons_per_booking: 5,
    allow_cancellation: true,
    cancellation_hours_before: 2,
    default_slot_capacity: 40,
    instructions_text: 'يرجى الحضور قبل الموعد بـ 15 دقيقة، وإبراز التذكرة الإلكترونية والرمز QR لموظف التنظيم عند البوابة، والالتزام بالزي المناسب والهدوء داخل الحرم الشريف.'
  }
};

let memoryDb = null;
let isWriting = false;

// قراءة قاعدة البيانات بأمان
function loadDb() {
  if (memoryDb) return memoryDb;
  if (!fs.existsSync(DB_FILE)) {
    saveDb(DEFAULT_SCHEMA);
    memoryDb = JSON.parse(JSON.stringify(DEFAULT_SCHEMA));
    return memoryDb;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    memoryDb = JSON.parse(raw);
    // دمج الإعدادات الافتراضية إن نقصت
    memoryDb.settings = { ...DEFAULT_SCHEMA.settings, ...(memoryDb.settings || {}) };
    return memoryDb;
  } catch (err) {
    console.error('خطأ في قراءة ملف قاعدة البيانات، استخدام النسخة الاحتياطية إن وجدت:', err);
    if (fs.existsSync(BACKUP_FILE)) {
      const rawBackup = fs.readFileSync(BACKUP_FILE, 'utf8');
      memoryDb = JSON.parse(rawBackup);
      return memoryDb;
    }
    memoryDb = JSON.parse(JSON.stringify(DEFAULT_SCHEMA));
    return memoryDb;
  }
}

// كتابة ذرية آمنة (Atomic Write) مع نسخة احتياطية
function saveDb(data) {
  const dbData = data || memoryDb;
  const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
  try {
    const jsonStr = JSON.stringify(dbData, null, 2);
    fs.writeFileSync(tempFile, jsonStr, 'utf8');
    // نسخ احتياطي سريع للملف السابق
    if (fs.existsSync(DB_FILE)) {
      try {
        fs.copyFileSync(DB_FILE, BACKUP_FILE);
      } catch (e) {}
    }
    fs.renameSync(tempFile, DB_FILE);
    memoryDb = dbData;
  } catch (err) {
    console.error('فشل حفظ قاعدة البيانات:', err);
    if (fs.existsSync(tempFile)) {
      try { fs.unlinkSync(tempFile); } catch (e) {}
    }
    throw err;
  }
}

// تنفيذ معاملة ذرية متزامنة لمنع التنافس على المقاعد
function transaction(fn) {
  const db = loadDb();
  // محاكاة قفل المعاملات الذري
  try {
    const result = fn(db);
    saveDb(db);
    return result;
  } catch (error) {
    // التراجع وإعادة التحميل من الملف
    memoryDb = null;
    loadDb();
    throw error;
  }
}

// Helper: توليد معرّف عشوائي
function generateId(prefix = '') {
  return `${prefix}${crypto.randomUUID()}`;
}

// Helper: توليد رقم حجز سهل القراءة مثل HJ-2026-7842
function generateBookingRef() {
  const year = new Date().getFullYear();
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `HJ-${year}-${rand}`;
}

module.exports = {
  loadDb,
  saveDb,
  transaction,
  generateId,
  generateBookingRef
};
