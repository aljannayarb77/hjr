const express = require('express');
const router = express.Router();
const { loadDb } = require('../db');
const { authenticateToken, requireStaff } = require('../auth');

// إحصائيات لوحة التحكم الشاملة (للمدير والموظف)
router.get('/dashboard', authenticateToken, requireStaff, (req, res) => {
  try {
    const db = loadDb();
    const todayStr = new Date().toISOString().split('T')[0];

    const appointmentsMap = {};
    let totalCapacity = 0;
    let fullSlotsCount = 0;

    db.appointments.forEach(a => {
      appointmentsMap[a.id] = a;
      totalCapacity += (a.capacity || 0);
      if ((a.capacity - (a.booked_count || 0)) <= 0) {
        fullSlotsCount++;
      }
    });

    const totalBookings = db.bookings.length;
    let todayBookings = 0;
    let confirmedCount = 0;
    let usedCount = 0;
    let cancelledCount = 0;
    let totalPersonsServed = 0;

    db.bookings.forEach(b => {
      const app = appointmentsMap[b.appointment_id];
      if (app && app.date === todayStr) {
        todayBookings++;
      }
      if (b.status === 'CONFIRMED') confirmedCount++;
      else if (b.status === 'USED') {
        usedCount++;
        totalPersonsServed += (b.persons_count || 1);
      }
      else if (b.status === 'CANCELLED') cancelledCount++;
    });

    const activeBookingsCount = confirmedCount + usedCount;
    const occupancyRate = totalCapacity > 0 
      ? Math.round((activeBookingsCount / totalCapacity) * 100) 
      : 0;

    // تجميع الحجوزات للأيام السبعة القادمة للرسم البياني
    const next7Days = {};
    for (let i = 0; i < 7; i++) {
      const d = new Date();
      d.setDate(d.getDate() + i);
      const dStr = d.toISOString().split('T')[0];
      next7Days[dStr] = { date: dStr, bookings: 0, capacity: 0 };
    }

    db.appointments.forEach(a => {
      if (next7Days[a.date]) {
        next7Days[a.date].capacity += (a.capacity || 0);
      }
    });

    db.bookings.forEach(b => {
      const app = appointmentsMap[b.appointment_id];
      if (app && next7Days[app.date] && ['CONFIRMED', 'USED'].includes(b.status)) {
        next7Days[app.date].bookings += (b.persons_count || 1);
      }
    });

    res.json({
      success: true,
      stats: {
        total_bookings: totalBookings,
        today_bookings: todayBookings,
        confirmed_bookings: confirmedCount,
        used_bookings: usedCount,
        cancelled_bookings: cancelledCount,
        full_slots_count: fullSlotsCount,
        total_capacity: totalCapacity,
        total_persons_served: totalPersonsServed,
        occupancy_rate: occupancyRate
      },
      chart_data: Object.values(next7Days),
      recent_activity: db.audit_logs.slice(0, 10)
    });
  } catch (err) {
    console.error('خطأ في استخراج إحصائيات لوحة التحكم:', err);
    res.status(500).json({ success: false, message: 'فشل تحميل الإحصائيات.' });
  }
});

// تقرير مفصل حسب الفترة الزمنية (يوم، أسبوع، شهر، مخصص)
router.get('/period', authenticateToken, requireStaff, (req, res) => {
  try {
    const { period = 'week', start_date, end_date } = req.query;
    const db = loadDb();

    let startDateStr = start_date;
    let endDateStr = end_date;

    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (period === 'day') {
      startDateStr = todayStr;
      endDateStr = todayStr;
    } else if (period === 'week') {
      const d = new Date();
      d.setDate(d.getDate() - 7);
      startDateStr = d.toISOString().split('T')[0];
      endDateStr = todayStr;
    } else if (period === 'month') {
      const d = new Date();
      d.setDate(d.getDate() - 30);
      startDateStr = d.toISOString().split('T')[0];
      endDateStr = todayStr;
    }

    const appointmentsMap = {};
    db.appointments.forEach(a => { appointmentsMap[a.id] = a; });

    let filteredBookings = db.bookings.filter(b => {
      const app = appointmentsMap[b.appointment_id];
      if (!app) return false;
      if (startDateStr && app.date < startDateStr) return false;
      if (endDateStr && app.date > endDateStr) return false;
      return true;
    });

    let confirmed = 0, used = 0, cancelled = 0, totalPersons = 0;
    filteredBookings.forEach(b => {
      if (b.status === 'CONFIRMED') confirmed++;
      else if (b.status === 'USED') { used++; totalPersons += b.persons_count; }
      else if (b.status === 'CANCELLED') cancelled++;
    });

    res.json({
      success: true,
      period,
      start_date: startDateStr,
      end_date: endDateStr,
      metrics: {
        total: filteredBookings.length,
        confirmed,
        used,
        cancelled,
        total_persons: totalPersons,
        attendance_rate: (confirmed + used) > 0 ? Math.round((used / (confirmed + used)) * 100) : 0
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'فشل إعداد التقرير.' });
  }
});

// تصدير جدول الحجوزات إلى ملف CSV متوافق مع Excel والأحرف العربية (BOM UTF-8)
router.get('/export-csv', authenticateToken, requireStaff, (req, res) => {
  try {
    const { date, status } = req.query;
    const db = loadDb();

    const appointmentsMap = {};
    db.appointments.forEach(a => { appointmentsMap[a.id] = a; });

    let list = [...db.bookings];
    if (date) {
      list = list.filter(b => {
        const app = appointmentsMap[b.appointment_id];
        return app && app.date === date;
      });
    }
    if (status && status !== 'ALL') {
      list = list.filter(b => b.status === status);
    }

    // كتابة ترويسة CSV متوافقة مع Excel
    const headers = [
      'رقم الحجز',
      'الاسم الكامل',
      'رقم الجوال',
      'الهوية / الوثيقة',
      'الجنسية',
      'تاريخ الموعد',
      'وقت الموعد',
      'عدد الأفراد',
      'حالة الحجز',
      'تاريخ إنشاء الحجز',
      'تاريخ تسجيل الدخول'
    ];

    const statusTranslations = {
      CONFIRMED: 'مؤكد',
      USED: 'مستخدم (تم الدخول)',
      CANCELLED: 'ملغى',
      EXPIRED: 'منتهي الصلاحية',
      PENDING: 'معلق'
    };

    const rows = list.map(b => {
      const app = appointmentsMap[b.appointment_id] || {};
      const statusAr = statusTranslations[b.status] || b.status;
      const timeStr = app.start_time ? `${app.start_time} - ${app.end_time}` : '-';
      
      const escapeCsv = (field) => {
        const val = String(field || '').replace(/"/g, '""');
        return `"${val}"`;
      };

      return [
        escapeCsv(b.booking_ref),
        escapeCsv(b.full_name),
        escapeCsv(b.phone),
        escapeCsv(b.national_id),
        escapeCsv(b.nationality),
        escapeCsv(app.date || '-'),
        escapeCsv(timeStr),
        escapeCsv(b.persons_count),
        escapeCsv(statusAr),
        escapeCsv(b.created_at ? b.created_at.replace('T', ' ').substring(0, 19) : '-'),
        escapeCsv(b.used_at ? b.used_at.replace('T', ' ').substring(0, 19) : '-')
      ].join(',');
    });

    // إضافة BOM لضمان قراءة ترميز UTF-8 بالعربية في Excel بدون مشاكل أحرف
    const csvContent = '\uFEFF' + headers.join(',') + '\n' + rows.join('\n');

    const filename = `alhijr_bookings_${new Date().toISOString().split('T')[0]}.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.status(200).send(csvContent);
  } catch (err) {
    console.error('خطأ في تصدير CSV:', err);
    res.status(500).json({ success: false, message: 'فشل تصدير ملف البيانات.' });
  }
});

module.exports = router;
