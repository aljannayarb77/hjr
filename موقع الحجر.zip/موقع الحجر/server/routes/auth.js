const express = require('express');
const router = express.Router();
const { loadDb, transaction, generateId } = require('../db');
const { hashPassword, comparePassword, generateToken, authenticateToken, requireAdmin } = require('../auth');
const { logAudit } = require('../services/auditService');

// تسجيل الدخول (مدير / موظف)
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ success: false, message: 'يرجى إدخال اسم المستخدم وكلمة المرور.' });
    }

    const db = loadDb();
    const user = db.users.find(u => 
      (u.username.toLowerCase() === username.trim().toLowerCase() || 
       (u.email && u.email.toLowerCase() === username.trim().toLowerCase())) && 
      u.is_active
    );

    if (!user) {
      return res.status(401).json({ success: false, message: 'بيانات الدخول غير صحيحة أو الحساب غير نشط.' });
    }

    const isMatch = await comparePassword(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'بيانات الدخول غير صحيحة.' });
    }

    const token = generateToken(user);

    logAudit(user, 'USER_LOGIN', 'user', user.id, { username: user.username, role: user.role }, req.ip);

    res.json({
      success: true,
      message: 'تم تسجيل الدخول بنجاح.',
      token,
      user: {
        id: user.id,
        username: user.username,
        full_name: user.full_name,
        role: user.role,
        email: user.email
      }
    });
  } catch (err) {
    console.error('خطأ في تسجيل الدخول:', err);
    res.status(500).json({ success: false, message: 'حدث خطأ في الخادم أثناء تسجيل الدخول.' });
  }
});

// التحقق من الجلسة الحالية
router.get('/me', authenticateToken, (req, res) => {
  res.json({
    success: true,
    user: {
      id: req.user.id,
      username: req.user.username,
      full_name: req.user.full_name,
      role: req.user.role,
      email: req.user.email
    }
  });
});

// جلب قائمة المستخدمين (للمدير فقط)
router.get('/users', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDb();
  const safeUsers = db.users.map(u => ({
    id: u.id,
    username: u.username,
    full_name: u.full_name,
    role: u.role,
    email: u.email,
    created_at: u.created_at,
    is_active: u.is_active
  }));
  res.json({ success: true, users: safeUsers });
});

// إضافة مستخدم/موظف جديد (للمدير فقط)
router.post('/users', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { username, password, full_name, role = 'STAFF', email } = req.body;
    if (!username || !password || !full_name) {
      return res.status(400).json({ success: false, message: 'يرجى إكمال جميع الحقول المطلوبة.' });
    }

    const db = loadDb();
    if (db.users.some(u => u.username.toLowerCase() === username.trim().toLowerCase())) {
      return res.status(400).json({ success: false, message: 'اسم المستخدم مستخدم مسبقًا.' });
    }

    const hashedPassword = await hashPassword(password);
    const newUser = {
      id: generateId('usr_'),
      username: username.trim(),
      password_hash: hashedPassword,
      full_name: full_name.trim(),
      role: role === 'ADMIN' ? 'ADMIN' : 'STAFF',
      email: email ? email.trim() : null,
      is_active: true,
      created_at: new Date().toISOString()
    };

    transaction((database) => {
      database.users.push(newUser);
      logAudit(req.user, 'CREATE_USER', 'user', newUser.id, { username: newUser.username, role: newUser.role }, req.ip);
    });

    res.json({
      success: true,
      message: 'تم إنشاء الحساب بنجاح.',
      user: {
        id: newUser.id,
        username: newUser.username,
        full_name: newUser.full_name,
        role: newUser.role
      }
    });
  } catch (err) {
    console.error('خطأ في إنشاء المستخدم:', err);
    res.status(500).json({ success: false, message: 'فشل إنشاء المستخدم.' });
  }
});

// حذف مستخدم (للمدير فقط)
router.delete('/users/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    if (!id) {
      return res.status(400).json({ success: false, message: 'معرف المستخدم غير محدد.' });
    }

    // منع المدير من حذف حسابه الحالي
    if (req.user.id === id) {
      return res.status(400).json({ success: false, message: 'لا يمكنك حذف حسابك الحالي الذي تستخدمه لتسجيل الدخول.' });
    }

    const db = loadDb();
    const userIndex = db.users.findIndex(u => u.id === id);
    if (userIndex === -1) {
      return res.status(404).json({ success: false, message: 'المستخدم غير موجود.' });
    }

    const targetUser = db.users[userIndex];

    transaction((database) => {
      const idx = database.users.findIndex(u => u.id === id);
      if (idx !== -1) {
        database.users.splice(idx, 1);
        logAudit(req.user, 'DELETE_USER', 'user', id, { username: targetUser.username, name: targetUser.full_name }, req.ip);
      }
    });

    res.json({
      success: true,
      message: `تم حذف المستخدم (${targetUser.full_name || targetUser.username}) بنجاح.`
    });
  } catch (err) {
    console.error('خطأ في حذف المستخدم:', err);
    res.status(500).json({ success: false, message: 'فشل حذف المستخدم.' });
  }
});

module.exports = router;
