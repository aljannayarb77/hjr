const express = require('express');
const router = express.Router();
const { loadDb, transaction } = require('../db');
const { authenticateToken, requireAdmin } = require('../auth');
const { logAudit } = require('../services/auditService');

// جلب الإعدادات العامة للمنصة (عام)
router.get('/', (req, res) => {
  const db = loadDb();
  res.json({
    success: true,
    settings: db.settings
  });
});

// تعديل إعدادات المنصة (مدير فقط)
router.put('/', authenticateToken, requireAdmin, (req, res) => {
  try {
    const updateData = req.body;
    let newSettings = null;

    transaction((db) => {
      db.settings = {
        ...db.settings,
        ...updateData
      };
      newSettings = db.settings;
      logAudit(req.user, 'UPDATE_SETTINGS', 'settings', 'global', updateData, req.ip);
    });

    res.json({
      success: true,
      message: 'تم حفظ إعدادات النظام بنجاح.',
      settings: newSettings
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'فشل حفظ الإعدادات.' });
  }
});

module.exports = router;
