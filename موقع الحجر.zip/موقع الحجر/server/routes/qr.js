const express = require('express');
const router = express.Router();
const { verifyQr, checkInBooking } = require('../services/bookingService');
const { authenticateToken, requireStaff } = require('../auth');

// التحقق من رمز QR (للموظفين)
router.post('/verify', authenticateToken, requireStaff, (req, res) => {
  try {
    const { qr_data } = req.body;
    if (!qr_data) {
      return res.status(400).json({ success: false, message: 'لم يتم استلام أي رمز QR للتحقق.' });
    }

    const verificationResult = verifyQr(qr_data);
    res.json({
      success: true,
      result: verificationResult
    });
  } catch (err) {
    console.error('خطأ في فحص رمز QR:', err);
    res.status(500).json({ success: false, message: 'حدث خطأ غير متوقع أثناء فحص الرمز.' });
  }
});

// تسجيل دخول الزائر الفعلي بعد التحقق
router.post('/check-in', authenticateToken, requireStaff, (req, res) => {
  try {
    const { booking_id } = req.body;
    if (!booking_id) {
      return res.status(400).json({ success: false, message: 'يرجى تحديد الحجز المراد تسجيل دخوله.' });
    }

    const checkedIn = checkInBooking(booking_id, req.user, req.ip);
    res.json({
      success: true,
      message: 'تم تسجيل الدخول بنجاح وتحديث حالة الحجز إلى مستخدم.',
      booking: checkedIn
    });
  } catch (err) {
    res.status(400).json({
      success: false,
      message: err.message || 'فشل تسجيل دخول الزائر.'
    });
  }
});

module.exports = router;
