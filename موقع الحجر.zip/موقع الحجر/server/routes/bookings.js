const express = require('express');
const router = express.Router();
const { loadDb } = require('../db');
const { createBooking, lookupBooking, cancelBooking, checkInBooking } = require('../services/bookingService');
const { generateQrImage } = require('../services/qrService');
const { authenticateToken, requireStaff } = require('../auth');
const { sendBookingConfirmation } = require('../services/notificationService');
const { APP_URL } = require('../config');

// إنشاء حجز جديد (عام)
router.post('/', async (req, res) => {
  try {
    const bookingResult = await createBooking(req.body, req.ip);
    res.status(201).json({
      success: true,
      message: 'تم تأكيد حجزك بنجاح.',
      booking: bookingResult
    });
  } catch (err) {
    res.status(400).json({
      success: false,
      message: err.message || 'حدث خطأ أثناء معالجة الحجز.'
    });
  }
});

// الاستعلام عن الحجز (عام)
router.post('/lookup', async (req, res) => {
  try {
    const { booking_ref, phone } = req.body;
    const booking = await lookupBooking(booking_ref, phone);
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'لم يتم العثور على حجز مطابق للبيانات المدخلة. يرجى التأكد من رقم الحجز ورقم الجوال.'
      });
    }
    res.json({ success: true, booking });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message || 'فشل الاستعلام عن الحجز.' });
  }
});

// إلغاء الحجز (الزائر أو الإدارة)
router.post('/:id/cancel', async (req, res) => {
  try {
    // التحقق إن كان المستخدم مسجلاً (موظف/مدير) أو زائر عادي
    let actor = 'الزائر';
    const authHeader = req.headers['authorization'];
    if (authHeader) {
      try {
        const token = authHeader.split(' ')[1];
        const jwt = require('jsonwebtoken');
        const { JWT_SECRET } = require('../config');
        const decoded = jwt.verify(token, JWT_SECRET);
        actor = decoded;
      } catch (e) {}
    }

    const cancelled = cancelBooking(req.params.id, actor, req.ip);
    res.json({
      success: true,
      message: 'تم إلغاء الحجز بنجاح وإتاحة المقعد لزائر آخر.',
      booking: cancelled
    });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message || 'فشل إلغاء الحجز.' });
  }
});

// جلب تفاصيل حجز محدد بالمعرف أو الرقم المرجعي
router.get('/:id', async (req, res) => {
  try {
    const db = loadDb();
    const booking = db.bookings.find(b => b.id === req.params.id || b.booking_ref === req.params.id);
    if (!booking) {
      return res.status(404).json({ success: false, message: 'الحجز غير موجود.' });
    }

    const appointment = db.appointments.find(a => a.id === booking.appointment_id) || null;
    const qrVerificationPayload = `${APP_URL}/ticket.html?ref=${booking.booking_ref}&token=${booking.qr_token}`;
    const qrImage = await generateQrImage(qrVerificationPayload);

    res.json({
      success: true,
      booking: {
        ...booking,
        appointment,
        qr_image: qrImage
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'خطأ في جلب بيانات الحجز.' });
  }
});

// استعراض وإدارة قائمة الحجوزات مع البحث والتصفية والصفحات (موظف / مدير)
router.get('/', authenticateToken, requireStaff, (req, res) => {
  try {
    const {
      search,
      status,
      date,
      appointment_id,
      page = 1,
      limit = 20
    } = req.query;

    const db = loadDb();
    let results = [...db.bookings];

    // خريطة المواعيد لسهولة الفلترة والربط
    const appointmentsMap = {};
    db.appointments.forEach(a => { appointmentsMap[a.id] = a; });

    // تصفية حسب التاريخ
    if (date) {
      results = results.filter(b => {
        const app = appointmentsMap[b.appointment_id];
        return app && app.date === date;
      });
    }

    // تصفية حسب الموعد المحدد
    if (appointment_id) {
      results = results.filter(b => b.appointment_id === appointment_id);
    }

    // تصفية حسب الحالة
    if (status && status !== 'ALL') {
      results = results.filter(b => b.status === status);
    }

    // البحث بالاسم، رقم الحجز، رقم الجوال، أو رقم الهوية
    if (search) {
      const q = search.trim().toLowerCase();
      results = results.filter(b => 
        (b.booking_ref && b.booking_ref.toLowerCase().includes(q)) ||
        (b.full_name && b.full_name.toLowerCase().includes(q)) ||
        (b.phone && b.phone.includes(q)) ||
        (b.national_id && b.national_id.includes(q))
      );
    }

    // الترتيب حسب الأحدث
    results.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    const total = results.length;
    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 20;
    const startIndex = (pageNum - 1) * limitNum;
    const paginated = results.slice(startIndex, startIndex + limitNum);

    // تضمين بيانات الموعد مع كل حجز
    const enriched = paginated.map(b => ({
      ...b,
      appointment: appointmentsMap[b.appointment_id] || null
    }));

    res.json({
      success: true,
      total,
      page: pageNum,
      limit: limitNum,
      total_pages: Math.ceil(total / limitNum),
      bookings: enriched
    });
  } catch (err) {
    console.error('خطأ في جلب الحجوزات:', err);
    res.status(500).json({ success: false, message: 'فشل جلب قائمة الحجوزات.' });
  }
});

// إعادة إرسال التذكرة / الإشعار (موظف / مدير)
router.post('/:id/resend-ticket', authenticateToken, requireStaff, async (req, res) => {
  try {
    const db = loadDb();
    const booking = db.bookings.find(b => b.id === req.params.id);
    if (!booking) return res.status(404).json({ success: false, message: 'الحجز غير موجود.' });

    const appointment = db.appointments.find(a => a.id === booking.appointment_id);
    const ticketUrl = `${APP_URL}/ticket.html?ref=${booking.booking_ref}&token=${booking.qr_token}`;

    await sendBookingConfirmation({ booking, appointment, ticketUrl });

    res.json({ success: true, message: `تمت إعادة إرسال التذكرة بنجاح إلى الرقم ${booking.phone}.` });
  } catch (err) {
    res.status(500).json({ success: false, message: 'فشل إرسال التذكرة.' });
  }
});

// تسجيل دخول يدوي للزائر (موظف / مدير)
router.post('/:id/manual-checkin', authenticateToken, requireStaff, (req, res) => {
  try {
    const updated = checkInBooking(req.params.id, req.user, req.ip);
    res.json({
      success: true,
      message: 'تم تسجيل دخول الزائر يدويًا بنجاح.',
      booking: updated
    });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message || 'فشل تسجيل الدخول.' });
  }
});

module.exports = router;
