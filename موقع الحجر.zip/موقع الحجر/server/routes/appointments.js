const express = require('express');
const router = express.Router();
const { loadDb, transaction, generateId } = require('../db');
const { authenticateToken, requireAdmin, requireStaff } = require('../auth');
const { logAudit } = require('../services/auditService');
const { getSlotEndTime } = require('../services/bookingService');

// حساب حالة الموعد اللحظية
function computeSlotStatus(appointment) {
  const now = new Date();
  const slotEnd = getSlotEndTime(appointment);
  
  if (slotEnd < now) {
    return 'EXPIRED'; // منتهي
  }
  if (!appointment.is_active) {
    return 'UNAVAILABLE'; // غير متاح / معطل
  }
  const remaining = appointment.capacity - (appointment.booked_count || 0);
  if (remaining <= 0) {
    return 'FULL'; // مكتمل
  }
  return 'AVAILABLE'; // متاح
}

// جلب التواريخ المتاحة للحجز (عام)
router.get('/available-dates', (req, res) => {
  const db = loadDb();
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  const datesMap = {};
  db.appointments.forEach(app => {
    if (app.date >= todayStr) {
      if (!datesMap[app.date]) {
        datesMap[app.date] = {
          date: app.date,
          total_slots: 0,
          available_slots: 0
        };
      }
      datesMap[app.date].total_slots += 1;
      const status = computeSlotStatus(app);
      if (status === 'AVAILABLE') {
        datesMap[app.date].available_slots += 1;
      }
    }
  });

  const dates = Object.values(datesMap).sort((a, b) => a.date.localeCompare(b.date));
  res.json({ success: true, dates });
});

// جلب المواعيد ليوم محدد أو المواعيد القادمة (عام)
router.get('/', (req, res) => {
  const { date, all } = req.query;
  const db = loadDb();
  let list = db.appointments;

  if (date) {
    list = list.filter(a => a.date === date);
  }

  // إذا لم يكن طلب الإدارة الشامل، لا تعرض المواعيد القديمة جداً
  if (!all && !date) {
    const todayStr = new Date().toISOString().split('T')[0];
    list = list.filter(a => a.date >= todayStr);
  }

  // ترتيب حسب التاريخ ووقت البداية ابتداءً من 06:00 صباحاً وحتى منتصف الليل
  list.sort((a, b) => {
    if (a.date !== b.date) return a.date.localeCompare(b.date);
    const getHourSort = (t) => {
      const h = parseInt((t || '00:00').split(':')[0], 10);
      return h < 6 ? h + 24 : h;
    };
    const diff = getHourSort(a.start_time) - getHourSort(b.start_time);
    if (diff !== 0) return diff;
    return (a.start_time || '').localeCompare(b.start_time || '');
  });

  const formatted = list.map(a => {
    const status = computeSlotStatus(a);
    const remaining = Math.max(0, a.capacity - (a.booked_count || 0));
    return {
      ...a,
      remaining_seats: remaining,
      status
    };
  });

  res.json({ success: true, appointments: formatted });
});

// جلب تفاصيل موعد محدد
router.get('/:id', (req, res) => {
  const db = loadDb();
  const app = db.appointments.find(a => a.id === req.params.id);
  if (!app) {
    return res.status(404).json({ success: false, message: 'الموعد غير موجود.' });
  }
  const status = computeSlotStatus(app);
  const remaining = Math.max(0, app.capacity - (app.booked_count || 0));
  res.json({ success: true, appointment: { ...app, remaining_seats: remaining, status } });
});

// إنشاء موعد جديد (مدير فقط)
router.post('/', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { date, start_time, end_time, capacity, notes, is_active = true } = req.body;
    if (!date || !start_time || !end_time || !capacity) {
      return res.status(400).json({ success: false, message: 'يرجى إكمال التاريخ وأوقات البداية والنهاية والسعة.' });
    }

    const cap = parseInt(capacity, 10);
    if (isNaN(cap) || cap < 1) {
      return res.status(400).json({ success: false, message: 'السعة يجب أن تكون رقماً أكبر من صفر.' });
    }

    const newAppointment = {
      id: generateId('app_'),
      date,
      start_time,
      end_time,
      capacity: cap,
      booked_count: 0,
      is_active: Boolean(is_active),
      notes: notes ? notes.trim() : '',
      created_at: new Date().toISOString()
    };

    transaction((db) => {
      // فحص عدم تكرار نفس الموعد بالضبط لنفس التوقيت
      const duplicate = db.appointments.find(a => 
        a.date === date && a.start_time === start_time && a.end_time === end_time
      );
      if (duplicate) {
        throw new Error('يوجد موعد مسجل مسبقًا بنفس التوقيت في هذا اليوم.');
      }
      db.appointments.push(newAppointment);
      logAudit(req.user, 'CREATE_APPOINTMENT', 'appointment', newAppointment.id, {
        date,
        time: `${start_time} - ${end_time}`,
        capacity: cap
      }, req.ip);
    });

    res.json({ success: true, message: 'تم إنشاء الموعد بنجاح.', appointment: newAppointment });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message || 'فشل إنشاء الموعد.' });
  }
});

// توليد مواعيد تلقائية مجدولة ليوم أو نطاق أيام (مدير فقط)
router.post('/bulk-generate', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { date, slots, default_capacity = 40 } = req.body;
    if (!date || !Array.isArray(slots) || slots.length === 0) {
      return res.status(400).json({ success: false, message: 'يرجى تحديد التاريخ والفترات الزمنية المطلوبة.' });
    }

    const createdList = [];
    transaction((db) => {
      slots.forEach(slot => {
        const exists = db.appointments.some(a => 
          a.date === date && a.start_time === slot.start_time && a.end_time === slot.end_time
        );
        if (!exists) {
          const app = {
            id: generateId('app_'),
            date,
            start_time: slot.start_time,
            end_time: slot.end_time,
            capacity: parseInt(slot.capacity || default_capacity, 10),
            booked_count: 0,
            is_active: true,
            notes: slot.notes || '',
            created_at: new Date().toISOString()
          };
          db.appointments.push(app);
          createdList.push(app);
        }
      });
      logAudit(req.user, 'BULK_GENERATE_APPOINTMENTS', 'appointment', 'bulk', {
        date,
        count: createdList.length
      }, req.ip);
    });

    res.json({
      success: true,
      message: `تم توليد ${createdList.length} موعدًا بنجاح.`,
      created_count: createdList.length,
      appointments: createdList
    });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message || 'فشل توليد المواعيد.' });
  }
});

// تعديل موعد (مدير فقط)
router.put('/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { date, start_time, end_time, capacity, is_active, notes } = req.body;
    let updated = null;

    transaction((db) => {
      const app = db.appointments.find(a => a.id === req.params.id);
      if (!app) {
        throw new Error('الموعد غير موجود.');
      }

      if (capacity !== undefined) {
        const newCap = parseInt(capacity, 10);
        if (newCap < (app.booked_count || 0)) {
          throw new Error(`لا يمكن تقليل السعة عن عدد الحجوزات الحالية (${app.booked_count} حجز).`);
        }
        app.capacity = newCap;
      }

      if (date) app.date = date;
      if (start_time) app.start_time = start_time;
      if (end_time) app.end_time = end_time;
      if (is_active !== undefined) app.is_active = Boolean(is_active);
      if (notes !== undefined) app.notes = notes.trim();

      updated = { ...app };
      logAudit(req.user, 'UPDATE_APPOINTMENT', 'appointment', app.id, updated, req.ip);
    });

    res.json({ success: true, message: 'تم تعديل الموعد بنجاح.', appointment: updated });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message || 'فشل تعديل الموعد.' });
  }
});

// حذف موعد (مدير فقط)
router.delete('/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    transaction((db) => {
      const index = db.appointments.findIndex(a => a.id === req.params.id);
      if (index === -1) {
        throw new Error('الموعد غير موجود.');
      }

      const app = db.appointments[index];
      // التحقق من عدم وجود حجوزات مؤكدة للموعد
      const hasActiveBookings = db.bookings.some(b => 
        b.appointment_id === app.id && ['CONFIRMED', 'USED'].includes(b.status)
      );

      if (hasActiveBookings) {
        throw new Error('لا يمكن حذف موعد يحتوي على حجوزات مؤكدة أو مستخدمة، يمكنك تعطيله بدلاً من ذلك.');
      }

      db.appointments.splice(index, 1);
      logAudit(req.user, 'DELETE_APPOINTMENT', 'appointment', req.params.id, {
        date: app.date,
        time: `${app.start_time} - ${app.end_time}`
      }, req.ip);
    });

    res.json({ success: true, message: 'تم حذف الموعد بنجاح.' });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message || 'فشل حذف الموعد.' });
  }
});

module.exports = router;
