const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { JWT_SECRET, JWT_EXPIRES_IN, BCRYPT_SALT_ROUNDS } = require('./config');
const { loadDb } = require('./db');

// تشفير كلمة المرور
async function hashPassword(plainPassword) {
  return bcrypt.hash(plainPassword, BCRYPT_SALT_ROUNDS);
}

// مطابقة كلمة المرور
async function comparePassword(plainPassword, hashedPassword) {
  return bcrypt.compare(plainPassword, hashedPassword);
}

// توليد توكن JWT
function generateToken(user) {
  const payload = {
    id: user.id,
    username: user.username,
    role: user.role,
    full_name: user.full_name
  };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

// ميدل وير التحقق من تسجيل الدخول
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'يرجى تسجيل الدخول للوصول إلى هذه الشاشة.' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, message: 'انتهت صلاحية الجلسة، يرجى إعادة تسجيل الدخول.' });
    }
    // التأكد من أن المستخدم ما زال نشطاً
    const db = loadDb();
    const activeUser = db.users.find(u => u.id === user.id && u.is_active);
    if (!activeUser) {
      return res.status(403).json({ success: false, message: 'حساب المستخدم غير موجود أو معطل.' });
    }
    req.user = activeUser;
    next();
  });
}

// ميدل وير التحقق من صلاحية الموظف أو المدير
function requireStaff(req, res, next) {
  if (!req.user || !['ADMIN', 'STAFF'].includes(req.user.role)) {
    return res.status(403).json({ success: false, message: 'ليس لديك الصلاحية الكافية لتنفيذ هذا الإجراء.' });
  }
  next();
}

// ميدل وير التحقق من صلاحية المدير الكاملة
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'ADMIN') {
    return res.status(403).json({ success: false, message: 'هذا الإجراء مخصص لمدير النظام فقط.' });
  }
  next();
}

module.exports = {
  hashPassword,
  comparePassword,
  generateToken,
  authenticateToken,
  requireStaff,
  requireAdmin
};
