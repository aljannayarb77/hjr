const express = require('express');
const cors = require('cors');
const path = require('path');
const { PORT } = require('./config');
const { loadDb } = require('./db');

// استيراد مسارات الـ API
const authRoutes = require('./routes/auth');
const appointmentsRoutes = require('./routes/appointments');
const bookingsRoutes = require('./routes/bookings');
const qrRoutes = require('./routes/qr');
const reportsRoutes = require('./routes/reports');
const settingsRoutes = require('./routes/settings');

const app = express();

// إعدادات الميدل وير
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// خدمة الملفات الثابتة للواجهة الأمامية من المجلد الرئيسي للمشروع (متوافق مع GitHub Pages)
const rootDir = path.join(__dirname, '..');

// حماية الملفات والمجلدات الخلفية والحساسة من التحميل المباشر
app.use((req, res, next) => {
  const p = req.path.toLowerCase();
  if (
    p.startsWith('/server') ||
    p.startsWith('/data') ||
    p.startsWith('/node_modules') ||
    p.startsWith('/test') ||
    p.startsWith('/scratch') ||
    (p.endsWith('.json') && !p.endsWith('manifest.json')) ||
    p.endsWith('.md') ||
    p.startsWith('/.')
  ) {
    return res.status(403).json({ success: false, message: 'ممنوع الوصول للملفات الداخلية.' });
  }
  next();
});

app.use(express.static(rootDir));

// فحص سلامة الخادم
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    system: 'Al-Hijr Booking System',
    timestamp: new Date().toISOString()
  });
});

// تسجيل مسارات الـ API
app.use('/api/auth', authRoutes);
app.use('/api/appointments', appointmentsRoutes);
app.use('/api/bookings', bookingsRoutes);
app.use('/api/qr', qrRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/settings', settingsRoutes);

// معالجة الأخطاء العامة
app.use((err, req, res, next) => {
  console.error('خطأ غير معالج في الخادم:', err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'حدث خطأ داخلي في الخادم.'
  });
});

// توجيه أي طلب صفحة غير معرف إلى index.html أو 404
app.use((req, res) => {
  if (req.path.startsWith('/api')) {
    return res.status(404).json({ success: false, message: 'واجهة API غير موجودة.' });
  }
  res.sendFile(path.join(rootDir, 'index.html'));
});

// بدء تشغيل الخادم
app.listen(PORT, () => {
  // تهيئة أولية لقاعدة البيانات
  loadDb();
  console.log(`=======================================================`);
  console.log(`✓ منصة تنظيم مواعيد دخول الحِجر تعمل بنجاح!`);
  console.log(`الرابط المحلي: http://localhost:${PORT}`);
  console.log(`لوحة التحكم:  http://localhost:${PORT}/admin.html`);
  console.log(`ماسح الـ QR:   http://localhost:${PORT}/scanner.html`);
  console.log(`=======================================================`);
});

module.exports = app;
