const bcrypt = require('bcryptjs');
const { loadDb, saveDb, generateId, generateBookingRef } = require('./db');
const { generateQrToken } = require('./services/qrService');

async function seed() {
  console.log('--- بدء تهيئة البيانات التجريبية للمنصة (Dummy Data) ---');

  const db = loadDb();

  // 1. إنشاء المستخدمين (مدير وموظف)
  const adminPasswordHash = await bcrypt.hash('admin123', 10);
  const staffPasswordHash = await bcrypt.hash('staff123', 10);

  db.users = [
    {
      id: 'usr_admin_01',
      username: 'admin',
      password_hash: adminPasswordHash,
      full_name: 'ماجد محسن الشهري (المدير العام)',
      email: 'admin@alhijr.local',
      role: 'ADMIN',
      is_active: true,
      created_at: new Date().toISOString()
    },
    {
      id: 'usr_staff_01',
      username: 'staff',
      password_hash: staffPasswordHash,
      full_name: 'فهد الغامدي (مشرف الدخول والتفويج)',
      email: 'staff@alhijr.local',
      role: 'STAFF',
      is_active: true,
      created_at: new Date().toISOString()
    }
  ];

  // 2. إنشاء المواعيد للأيام القادمة (كل بطاقة مدتها ساعتان بالضبط)
  const slotTimes = [
    { start: '06:00', end: '08:00', name: 'فترة الصباح الأولى (06:00 ص - 08:00 ص)' },
    { start: '08:00', end: '10:00', name: 'فترة الصباح الثانية (08:00 ص - 10:00 ص)' },
    { start: '10:00', end: '12:00', name: 'فترة قبل الظهر (10:00 ص - 12:00 م)' },
    { start: '13:00', end: '15:00', name: 'فترة بعد الظهر (01:00 م - 03:00 م)' },
    { start: '16:00', end: '18:00', name: 'فترة العصر (04:00 م - 06:00 م)' },
    { start: '22:00', end: '00:00', name: 'فترة المساء (10:00 م - 12:00 ص)' },
    { start: '00:00', end: '02:00', name: 'فترة منتصف الليل (12:00 ص - 02:00 ص)' }
  ];

  db.appointments = [];
  const today = new Date();

  // توليد مواعيد لمدة 8 أيام
  for (let dayOffset = 0; dayOffset < 8; dayOffset++) {
    const d = new Date(today);
    d.setDate(today.getDate() + dayOffset);
    const dateStr = d.toISOString().split('T')[0];

    slotTimes.forEach((slot, index) => {
      const appId = `app_${dateStr}_${slot.start.replace(':', '')}`;
      // جعل بعض المواعيد ممتلئة وبعضها متوفر لاختبار الحالات
      let initialBooked = 0;
      let capacity = 40;

      if (dayOffset === 0 && index === 0) {
        initialBooked = 40;
      } else if (dayOffset === 0 && index === 1) {
        initialBooked = 32;
      } else if (dayOffset === 1 && index === 2) {
        initialBooked = 15;
      }

      db.appointments.push({
        id: appId,
        date: dateStr,
        start_time: slot.start,
        end_time: slot.end,
        capacity,
        booked_count: initialBooked,
        is_active: true,
        notes: slot.name,
        created_at: new Date().toISOString()
      });
    });
  }

  // 3. إنشاء حجوزات تجريبية متنوعة (مؤكدة، مستخدمة، ملغاة)
  const todayStr = today.toISOString().split('T')[0];
  const targetAppId = `app_${todayStr}_0800`;
  const eveningAppId = `app_${todayStr}_2200`;

  db.bookings = [];
  db.qr_tokens = [];

  const sampleBookings = [
    {
      id: 'bk_demo_01',
      booking_ref: 'HJ-2026-1001',
      appointment_id: eveningAppId,
      full_name: 'محمد عبدالله باوزير',
      phone: '0555123456',
      email: 'm.bawazeer@example.com',
      national_id: '1088765432',
      nationality: 'سعودي',
      persons_count: 2,
      status: 'CONFIRMED',
      created_at: new Date().toISOString(),
      used_at: null,
      cancelled_at: null
    },
    {
      id: 'bk_demo_02',
      booking_ref: 'HJ-2026-1002',
      appointment_id: targetAppId,
      full_name: 'أحمد إبراهيم الدوسري',
      phone: '0501239876',
      email: 'a.dosari@example.com',
      national_id: '1099887766',
      nationality: 'سعودي',
      persons_count: 1,
      status: 'USED', // مستخدم مسبقاً لاختبار الماسح
      created_at: new Date(Date.now() - 3600000 * 5).toISOString(),
      used_at: new Date(Date.now() - 3600000 * 2).toISOString(),
      cancelled_at: null
    },
    {
      id: 'bk_demo_03',
      booking_ref: 'HJ-2026-1003',
      appointment_id: targetAppId,
      full_name: 'فهد سالم العتيبي',
      phone: '0567890123',
      email: 'f.otaibi@example.com',
      national_id: '1044556677',
      nationality: 'سعودي',
      persons_count: 3,
      status: 'CANCELLED', // ملغى لاختبار الماسح
      created_at: new Date(Date.now() - 3600000 * 8).toISOString(),
      used_at: null,
      cancelled_at: new Date(Date.now() - 3600000 * 4).toISOString()
    },
    {
      id: 'bk_demo_04',
      booking_ref: 'HJ-2026-1004',
      appointment_id: eveningAppId,
      full_name: 'عمر خالد المنصوري',
      phone: '0544332211',
      email: 'omar.mansoor@example.com',
      national_id: '2033445566',
      nationality: 'إماراتي',
      persons_count: 1,
      status: 'CONFIRMED', // صالح وجاهز للتجربة
      created_at: new Date().toISOString(),
      used_at: null,
      cancelled_at: null
    }
  ];

  sampleBookings.forEach(b => {
    const token = generateQrToken(b.id, b.booking_ref);
    b.qr_token = token;
    db.bookings.push(b);
    db.qr_tokens.push({
      token,
      booking_id: b.id,
      created_at: b.created_at,
      is_used: b.status === 'USED',
      used_at: b.used_at
    });
  });

  // 4. سجل التدقيق التجريبي
  db.audit_logs = [
    {
      id: 'log_seed_01',
      actor: 'admin (ADMIN)',
      action: 'SYSTEM_INITIALIZATION',
      entity_type: 'system',
      entity_id: 'init',
      details: { message: 'تهيئة النظام والمواعيد التجريبية بنجاح' },
      ip_address: '127.0.0.1',
      timestamp: new Date().toISOString()
    }
  ];

  saveDb(db);
  console.log('✓ تم حفظ البيانات التجريبية بنجاح في data/database.json');
  console.log('بيانات دخول المدير: admin / admin123');
  console.log('بيانات دخول الموظف: staff / staff123');
}

if (require.main === module) {
  seed().catch(err => {
    console.error('فشلت التهيئة:', err);
    process.exit(1);
  });
}

module.exports = { seed };
