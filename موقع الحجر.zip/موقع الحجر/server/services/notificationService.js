// خدمة الإشعارات (جاهزة للربط مع SMS / WhatsApp / Email)
const notificationsLog = [];

async function sendBookingConfirmation({ booking, appointment, ticketUrl }) {
  const message = `أهلاً بك ${booking.full_name}،
تم تأكيد حجزك لدخول الحِجر بنجاح.
رقم الحجز: ${booking.booking_ref}
التاريخ: ${appointment.date}
الوقت: من ${appointment.start_time} إلى ${appointment.end_time}
عدد الأفراد: ${booking.persons_count}
رابط التذكرة الإلكترونية: ${ticketUrl}
نرجو الحضور قبل الموعد بـ 15 دقيقة وإبراز رمز QR.`;

  const payload = {
    id: `notif_${Date.now()}_${Math.random().toString(36).substring(7)}`,
    booking_id: booking.id,
    booking_ref: booking.booking_ref,
    recipient_phone: booking.phone,
    recipient_email: booking.email || null,
    message,
    channels: ['SMS', 'WHATSAPP', 'EMAIL'],
    status: 'SENT_MOCK', // محاكاة الإرسال
    timestamp: new Date().toISOString()
  };

  notificationsLog.unshift(payload);
  console.log(`[إشعار جديد] تم إرسال إشعار الحجز ${booking.booking_ref} للرقم ${booking.phone}`);
  return payload;
}

function getRecentNotifications(limit = 20) {
  return notificationsLog.slice(0, limit);
}

module.exports = {
  sendBookingConfirmation,
  getRecentNotifications
};
