const { loadDb, saveDb, transaction, generateId, generateBookingRef } = require('../db');
const { generateQrToken, generateQrImage } = require('./qrService');
const { logAudit } = require('./auditService');
const { sendBookingConfirmation } = require('./notificationService');
const { APP_URL } = require('../config');

// تنظيف وتوحيد رقم الجوال (يدعم الأرقام السعودية والدولية)
function normalizePhone(phone) {
  if (!phone) return '';
  let cleaned = phone.replace(/[\s\-\(\)]/g, '');
  return cleaned;
}

// حساب التوقيت الفعلي الدقيق لنهاية الموعد مع مراعاة فترات الليل ومنتصف الليل
function getSlotEndTime(appointment) {
  const [endH, endM] = (appointment.end_time || '00:00').split(':').map(Number);
  const [startH, startM] = (appointment.start_time || '00:00').split(':').map(Number);
  const base = new Date(`${appointment.date}T00:00:00`);
  
  // إذا كانت البداية قبل الساعة 6 صباحاً (مثل 00:00 إلى 02:00)، فإنها تتبع ليلة اليوم المحدد
  let dayOffsetMs = 0;
  if (startH < 6) {
    dayOffsetMs = 24 * 60 * 60 * 1000;
  }
  
  let slotEndMs = base.getTime() + dayOffsetMs + (endH * 60 + endM) * 60 * 1000;
  // إذا كان وقت النهاية أقل أو يساوي وقت البداية (مثل 22:00 إلى 00:00)، فإن النهاية في منتصف الليل/اليوم التالي
  if ((endH * 60 + endM) <= (startH * 60 + startM)) {
    slotEndMs += 24 * 60 * 60 * 1000;
  }
  return new Date(slotEndMs);
}

// حساب التوقيت الفعلي لبداية الموعد
function getSlotStartTime(appointment) {
  const [startH, startM] = (appointment.start_time || '00:00').split(':').map(Number);
  const base = new Date(`${appointment.date}T00:00:00`);
  let dayOffsetMs = 0;
  if (startH < 6) {
    dayOffsetMs = 24 * 60 * 60 * 1000;
  }
  return new Date(base.getTime() + dayOffsetMs + (startH * 60 + startM) * 60 * 1000);
}

// إنشاء حجز جديد مع التحقق الذري من السعة ومنع التجاوز
async function createBooking(data, clientIp = '127.0.0.1') {
  const {
    appointment_id,
    full_name,
    phone,
    email,
    national_id,
    nationality,
    persons_count = 1
  } = data;

  // 1. التحقق من صحة المدخلات
  if (!appointment_id) throw new Error('يرجى تحديد الموعد المطلوب.');
  if (!full_name || full_name.trim().length < 3) throw new Error('يرجى إدخال الاسم الثلاثي بشكل صحيح.');
  if (!phone || phone.trim().length < 9) throw new Error('يرجى إدخال رقم جوال صحيح للتواصل.');
  if (!national_id || national_id.trim().length < 5) throw new Error('يرجى إدخال رقم الهوية أو الإقامة أو جواز السفر.');

  const count = parseInt(persons_count, 10);
  if (isNaN(count) || count < 1) throw new Error('عدد الأفراد غير صالح.');

  const db = loadDb();
  const maxPersons = db.settings.max_persons_per_booking || 5;
  if (count > maxPersons) {
    throw new Error(`الحد الأقصى لعدد الأفراد في الحجز الواحد هو ${maxPersons} أفراد.`);
  }

  // 2. التنفيذ داخل معاملة متزامنة ذرية لمنع التنافس اللحظي
  let newBooking = null;
  let targetAppointment = null;
  let qrToken = null;

  transaction((database) => {
    // جلب الموعد
    const appointment = database.appointments.find(a => a.id === appointment_id);
    if (!appointment) {
      throw new Error('الموعد المحدد غير موجود في النظام.');
    }
    if (!appointment.is_active) {
      throw new Error('هذا الموعد غير متاح حاليًا للحجز.');
    }

    // فحص التاريخ والوقت لتجنب المواعيد الماضية بدقة
    const now = new Date();
    const appointmentEnd = getSlotEndTime(appointment);
    if (appointmentEnd < now) {
      throw new Error('عذرًا، هذا الموعد قد مضى بالفعل ولا يمكن الحجز فيه.');
    }

    // فحص توفر المقاعد بدقة تامة
    const remainingSeats = appointment.capacity - (appointment.booked_count || 0);
    if (remainingSeats < count) {
      throw new Error('عذرًا، اكتمل العدد لهذا الموعد ولم تعد هناك مقاعد كافية.');
    }

    // فحص منع التكرار لنفس رقم الهوية في نفس اليوم
    const existingSameDay = database.bookings.find(b => 
      b.national_id === national_id.trim() && 
      b.status === 'CONFIRMED' &&
      database.appointments.some(app => app.id === b.appointment_id && app.date === appointment.date)
    );
    if (existingSameDay) {
      throw new Error('يوجد حجز مؤكد مسبقًا لنفس رقم الهوية في هذا اليوم. لا يمكن تكرار الحجز لنفس اليوم.');
    }

    // توليد رقم الحجز الفريد
    let bookingRef = generateBookingRef();
    while (database.bookings.some(b => b.booking_ref === bookingRef)) {
      bookingRef = generateBookingRef();
    }

    const bookingId = generateId('bk_');
    qrToken = generateQrToken(bookingId, bookingRef);

    // تحديث عدد المحجوز في الموعد
    appointment.booked_count = (appointment.booked_count || 0) + count;

    // إنشاء سجل الحجز
    const createdAt = new Date().toISOString();
    newBooking = {
      id: bookingId,
      booking_ref: bookingRef,
      appointment_id: appointment.id,
      full_name: full_name.trim(),
      phone: normalizePhone(phone),
      email: email ? email.trim() : null,
      national_id: national_id.trim(),
      nationality: nationality ? nationality.trim() : 'سعودي',
      persons_count: count,
      status: 'CONFIRMED', // مؤكد تلقائياً فور نجاح الفحص
      qr_token: qrToken,
      created_at: createdAt,
      used_at: null,
      cancelled_at: null
    };

    // حفظ سجل رمز QR
    database.qr_tokens.push({
      token: qrToken,
      booking_id: bookingId,
      created_at: createdAt,
      is_used: false,
      used_at: null
    });

    database.bookings.unshift(newBooking);
    targetAppointment = { ...appointment };

    logAudit('زائر', 'CREATE_BOOKING', 'booking', bookingId, {
      booking_ref: bookingRef,
      name: newBooking.full_name,
      persons: count,
      slot: `${appointment.date} ${appointment.start_time}`
    }, clientIp);
  });

  // توليد صورة الـ QR
  // ملاحظة أمنية: الـ QR يحتوي على رابط التحقق والـ Token الفريد فقط وليس بيانات حساسة
  const qrVerificationPayload = `${APP_URL}/ticket.html?ref=${newBooking.booking_ref}&token=${qrToken}`;
  const qrImage = await generateQrImage(qrVerificationPayload);

  // إرسال الإشعار المحاكى
  try {
    await sendBookingConfirmation({
      booking: newBooking,
      appointment: targetAppointment,
      ticketUrl: qrVerificationPayload
    });
  } catch (e) {
    console.error('فشل إرسال الإشعار:', e);
  }

  return {
    ...newBooking,
    appointment: targetAppointment,
    qr_image: qrImage
  };
}

// الاستعلام عن الحجز بواسطة رقم الحجز ورقم الجوال
async function lookupBooking(bookingRef, phone) {
  if (!bookingRef || !phone) {
    throw new Error('يرجى إدخال رقم الحجز ورقم الجوال للاستعلام.');
  }

  const cleanRef = bookingRef.trim().toUpperCase();
  const cleanPhone = normalizePhone(phone);

  const db = loadDb();
  const booking = db.bookings.find(b => 
    b.booking_ref.toUpperCase() === cleanRef && 
    (b.phone === cleanPhone || b.phone.endsWith(cleanPhone) || cleanPhone.endsWith(b.phone))
  );

  if (!booking) {
    return null;
  }

  const appointment = db.appointments.find(a => a.id === booking.appointment_id) || null;
  const qrVerificationPayload = `${APP_URL}/ticket.html?ref=${booking.booking_ref}&token=${booking.qr_token}`;
  const qrImage = await generateQrImage(qrVerificationPayload);

  return {
    ...booking,
    appointment,
    qr_image: qrImage
  };
}

// إلغاء الحجز
function cancelBooking(bookingId, actor = 'الزائر', clientIp = '127.0.0.1') {
  let cancelledBooking = null;

  transaction((database) => {
    const booking = database.bookings.find(b => b.id === bookingId || b.booking_ref === bookingId);
    if (!booking) {
      throw new Error('الحجز غير موجود.');
    }

    if (booking.status === 'CANCELLED') {
      throw new Error('هذا الحجز ملغى بالفعل.');
    }
    if (booking.status === 'USED') {
      throw new Error('لا يمكن إلغاء حجز تم استخدامه والدخول به مسبقًا.');
    }

    const appointment = database.appointments.find(a => a.id === booking.appointment_id);
    if (appointment) {
      // التحقق من سياسة الإلغاء بالساعات إن كانت محددة
      const hoursBefore = database.settings.cancellation_hours_before || 2;
      const slotStartTime = getSlotStartTime(appointment);
      const now = new Date();
      const diffHours = (slotStartTime - now) / (1000 * 60 * 60);

      // السماح للإدارة بالإلغاء دائماً، والزائر وفق السياسة
      const isAdmin = typeof actor === 'object' && actor.role === 'ADMIN';
      if (!isAdmin && diffHours < hoursBefore && diffHours > 0) {
        throw new Error(`عذرًا، تمنع سياسة الإلغاء إلغاء الموعد قبل أقل من ${hoursBefore} ساعات من وقت الدخول.`);
      }

      // خصم المقاعد المحجوزة لإتاحتها لمستخدمين آخرين
      appointment.booked_count = Math.max(0, (appointment.booked_count || 0) - booking.persons_count);
    }

    booking.status = 'CANCELLED';
    booking.cancelled_at = new Date().toISOString();

    // إبطال رمز QR
    const qrRec = database.qr_tokens.find(q => q.booking_id === booking.id || q.token === booking.qr_token);
    if (qrRec) {
      qrRec.is_used = true;
    }

    cancelledBooking = { ...booking };

    logAudit(actor, 'CANCEL_BOOKING', 'booking', booking.id, {
      booking_ref: booking.booking_ref,
      name: booking.full_name
    }, clientIp);
  });

  return cancelledBooking;
}

// التحقق من رمز QR أو رقم الحجز بواسطة الموظف
function verifyQr(tokenOrRef) {
  if (!tokenOrRef) {
    return {
      valid: false,
      status: 'INVALID',
      message: 'رمز QR غير مدخل أو غير صالح.'
    };
  }

  const query = tokenOrRef.trim();
  const db = loadDb();

  // استخراج token أو ref إذا كان رابطاً كاملاً
  let cleanToken = query;
  if (query.includes('token=')) {
    try {
      const url = new URL(query);
      cleanToken = url.searchParams.get('token') || query;
    } catch (e) {
      const match = query.match(/token=([a-zA-Z0-9\-_]+)/);
      if (match) cleanToken = match[1];
    }
  } else if (query.includes('ref=')) {
    try {
      const url = new URL(query);
      cleanToken = url.searchParams.get('ref') || query;
    } catch (e) {
      const match = query.match(/ref=([a-zA-Z0-9\-_]+)/);
      if (match) cleanToken = match[1];
    }
  }

  // البحث في الحجوزات
  const booking = db.bookings.find(b => 
    b.qr_token === cleanToken || 
    b.booking_ref.toUpperCase() === cleanToken.toUpperCase() ||
    b.id === cleanToken
  );

  if (!booking) {
    return {
      valid: false,
      status: 'NOT_FOUND',
      message: 'رمز QR غير مسجل في النظام أو التذكرة غير صحيحة.'
    };
  }

  const appointment = db.appointments.find(a => a.id === booking.appointment_id) || null;

  // 1. فحص إذا كان الحجز ملغى
  if (booking.status === 'CANCELLED') {
    return {
      valid: false,
      status: 'CANCELLED',
      message: 'هذا الحجز ملغى رسميًا ولا يسمح بالدخول.',
      booking,
      appointment
    };
  }

  // 2. فحص إذا كان الحجز مستخدم مسبقاً
  if (booking.status === 'USED') {
    return {
      valid: false,
      status: 'ALREADY_USED',
      message: 'تم استخدام هذا الحجز مسبقًا والدخول به.',
      used_at: booking.used_at,
      booking,
      appointment
    };
  }

  // 3. فحص تاريخ الموعد ومقارنته باليوم الحالي
  const todayStr = new Date().toISOString().split('T')[0];
  let dateNotice = null;
  if (appointment && appointment.date !== todayStr) {
    dateNotice = `تنبيه: تاريخ الحجز (${appointment.date}) لا يطابق تاريخ اليوم (${todayStr}).`;
  }

  // 4. الحجز صالح ومؤكد
  return {
    valid: true,
    status: 'VALID',
    message: 'الحجز صالح ومؤكد ✓',
    date_notice: dateNotice,
    booking,
    appointment
  };
}

// تسجيل دخول الزائر (Check-in) وتغيير الحالة إلى USED
function checkInBooking(bookingId, staffUser, clientIp = '127.0.0.1') {
  let updatedBooking = null;

  transaction((database) => {
    const booking = database.bookings.find(b => b.id === bookingId || b.booking_ref === bookingId || b.qr_token === bookingId);
    if (!booking) {
      throw new Error('الحجز غير موجود.');
    }

    if (booking.status === 'USED') {
      throw new Error(`تم استخدام هذا الحجز مسبقًا في ${booking.used_at}.`);
    }

    if (booking.status === 'CANCELLED') {
      throw new Error('لا يمكن تسجيل دخول حجز ملغى.');
    }

    const nowIso = new Date().toISOString();
    booking.status = 'USED';
    booking.used_at = nowIso;

    const qrRec = database.qr_tokens.find(q => q.booking_id === booking.id || q.token === booking.qr_token);
    if (qrRec) {
      qrRec.is_used = true;
      qrRec.used_at = nowIso;
    }

    updatedBooking = { ...booking };

    logAudit(staffUser, 'CHECK_IN_SUCCESS', 'booking', booking.id, {
      booking_ref: booking.booking_ref,
      staff: staffUser ? staffUser.username : 'موظف',
      visitor: booking.full_name,
      persons: booking.persons_count
    }, clientIp);
  });

  return updatedBooking;
}

module.exports = {
  createBooking,
  lookupBooking,
  cancelBooking,
  verifyQr,
  checkInBooking,
  normalizePhone,
  getSlotEndTime,
  getSlotStartTime
};
