const QRCode = require('qrcode');
const crypto = require('crypto');
const { JWT_SECRET } = require('../config');

// توليد رمز QR مشفر وآمن لا يكشف البيانات الشخصية الحساسة
function generateQrToken(bookingId, bookingRef) {
  const nonce = crypto.randomBytes(8).toString('hex');
  const payload = `${bookingId}|${bookingRef}|${nonce}`;
  const hmac = crypto.createHmac('sha256', JWT_SECRET).update(payload).digest('hex').substring(0, 16);
  return `HJ-V1-${nonce}-${hmac}`;
}

// توليد صورة QR كـ DataURL Base64
async function generateQrImage(qrPayload) {
  try {
    const dataUrl = await QRCode.toDataURL(qrPayload, {
      errorCorrectionLevel: 'H',
      type: 'image/png',
      margin: 2,
      color: {
        dark: '#0F382A', // أخضر زمردي داكن فخم
        light: '#FFFFFF'
      },
      width: 280
    });
    return dataUrl;
  } catch (err) {
    console.error('خطأ في توليد صورة QR:', err);
    throw err;
  }
}

module.exports = {
  generateQrToken,
  generateQrImage
};
