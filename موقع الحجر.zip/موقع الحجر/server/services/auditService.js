const { loadDb, saveDb, generateId } = require('../db');

function logAudit(actor, action, entityType, entityId, details = {}, ip = '127.0.0.1') {
  try {
    const db = loadDb();
    const entry = {
      id: generateId('log_'),
      actor: typeof actor === 'object' ? `${actor.username} (${actor.role})` : (actor || 'زائر / نظام'),
      action,
      entity_type: entityType,
      entity_id: entityId,
      details,
      ip_address: ip,
      timestamp: new Date().toISOString()
    };
    db.audit_logs.unshift(entry);
    // الاحتفاظ بآخر 1000 سجل فقط لسرعة الأداء
    if (db.audit_logs.length > 1000) {
      db.audit_logs = db.audit_logs.slice(0, 1000);
    }
    saveDb(db);
    return entry;
  } catch (err) {
    console.error('فشل تسجيل عملية التدقيق:', err);
  }
}

module.exports = {
  logAudit
};
