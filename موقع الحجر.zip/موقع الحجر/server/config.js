require('dotenv').config();

module.exports = {
  PORT: process.env.PORT || 3000,
  JWT_SECRET: process.env.JWT_SECRET || 'alhijr_secret_key_2026_secure_hash',
  JWT_EXPIRES_IN: '12h',
  BCRYPT_SALT_ROUNDS: 10,
  APP_URL: process.env.APP_URL || 'http://localhost:3000'
};
