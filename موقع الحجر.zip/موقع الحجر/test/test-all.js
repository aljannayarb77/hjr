const assert = require('assert');
const { loadDb, transaction } = require('../server/db');
const { createBooking, lookupBooking, cancelBooking, verifyQr, checkInBooking, getSlotEndTime } = require('../server/services/bookingService');
const { seed } = require('../server/seed');

async function runTests() {
  console.log('--- بدء اختبارات النظام الآلية الشاملة ---');

  // 1. إعادة التهيئة للبيانات التجريبية
  await seed();
  const db = loadDb();
  assert(db.users.length >= 2, 'يجب وجود مستخدمين على الأقل');
  assert(db.appointments.length > 0, 'يجب وجود مواعيد مسجلة');
  console.log('✓ اختبار 1: تهيئة قاعدة البيانات ناجحة');

  // 2. فحص موعد متاح وإجراء حجز ناجح
  const now = new Date();
  const availableSlot = db.appointments.find(a => {
    const end = getSlotEndTime(a);
    return end > now && (a.capacity - (a.booked_count || 0)) >= 2 && a.is_active;
  });
  assert(availableSlot, 'يجب العثور على موعد متاح للاختبار');
  const initialBooked = availableSlot.booked_count || 0;

  const bookingData = {
    appointment_id: availableSlot.id,
    full_name: 'سالم أحمد المحمدي',
    phone: '0599112233',
    email: 'salem@test.local',
    national_id: '1122334455',
    nationality: 'سعودي',
    persons_count: 2
  };

  const created = await createBooking(bookingData);
  assert(created.id, 'يجب أن يحتوي الحجز على معرّف');
  assert(created.booking_ref.startsWith('HJ-'), 'يجب أن يبدأ رقم الحجز بـ HJ-');
  assert.strictEqual(created.status, 'CONFIRMED', 'حالة الحجز يجب أن تكون CONFIRMED');
  assert(created.qr_image.startsWith('data:image/png;base64,'), 'يجب توليد صورة QR مشفرة');

  // التحقق من تحديث السعة المحجوزة
  const dbAfter = loadDb();
  const updatedSlot = dbAfter.appointments.find(a => a.id === availableSlot.id);
  assert.strictEqual(updatedSlot.booked_count, initialBooked + 2, 'يجب زيادة عدد المحجوز بدقة');
  console.log('✓ اختبار 2: إنشاء الحجز وتحديث السعة وتوليد QR ناجح');

  // 3. فحص منع تكرار الحجز لنفس رقم الهوية في نفس اليوم
  try {
    await createBooking({
      ...bookingData,
      phone: '0599112244' // هاتف مختلف لكن نفس الهوية
    });
    assert.fail('كان يجب رفض الحجز المكرر لنفس الهوية في نفس اليوم');
  } catch (err) {
    assert(err.message.includes('يوجد حجز مؤكد مسبقًا لنفس رقم الهوية'), 'يجب إظهار رسالة رفض التكرار');
    console.log('✓ اختبار 3: منع تكرار الحجز لنفس رقم الهوية في نفس اليوم ناجح');
  }

  // 4. فحص منع تجاوز السعة للموعد الممتلئ
  // إنشاء موعد سري بسعة 1 مقعد فقط
  let smallSlotId = null;
  transaction((d) => {
    smallSlotId = 'app_test_full_slot';
    d.appointments.push({
      id: smallSlotId,
      date: '2026-10-25',
      start_time: '12:00',
      end_time: '12:30',
      capacity: 1,
      booked_count: 1, // ممتلئ
      is_active: true,
      notes: 'موعد اختبار الامتلاء'
    });
  });

  try {
    await createBooking({
      appointment_id: smallSlotId,
      full_name: 'علي المنصور',
      phone: '0588888888',
      national_id: '1987654321',
      persons_count: 1
    });
    assert.fail('كان يجب رفض الحجز في موعد ممتلئ');
  } catch (err) {
    assert(err.message.includes('اكتمل العدد لهذا الموعد'), 'يجب رفض الحجز برسالة اكتمال العدد');
    console.log('✓ اختبار 4: منع تجاوز السعة للمواعيد المكتملة ناجح');
  }

  // 5. فحص الاستعلام عن الحجز (Lookup)
  const lookupSuccess = await lookupBooking(created.booking_ref, created.phone);
  assert(lookupSuccess, 'يجب العثور على الحجز عند إدخال الرقم والجوال الصحيحين');
  assert.strictEqual(lookupSuccess.full_name, 'سالم أحمد المحمدي');

  const lookupWrong = await lookupBooking(created.booking_ref, '0500000000');
  assert.strictEqual(lookupWrong, null, 'يجب عدم العثور على الحجز عند إدخال جوال خاطئ');
  console.log('✓ اختبار 5: الاستعلام عن الحجز بدقة وأمان ناجح');

  // 6. فحص التحقق من رمز QR للموظف
  const qrCheck = verifyQr(created.qr_token);
  assert.strictEqual(qrCheck.valid, true, 'يجب أن يكون الرمز صالحاً');
  assert.strictEqual(qrCheck.status, 'VALID');
  console.log('✓ اختبار 6: التحقق من رمز QR الصالح ناجح');

  // 7. فحص تسجيل دخول الزائر (Check-in) وتغيير الحالة إلى USED
  const staffUser = { id: 'usr_staff_01', username: 'staff', role: 'STAFF' };
  const checkedIn = checkInBooking(created.id, staffUser);
  assert.strictEqual(checkedIn.status, 'USED', 'يجب أن تتحول الحالة إلى USED');
  assert(checkedIn.used_at, 'يجب تسجيل تاريخ الاستخدام');

  // فحص محاولة المسح مرة أخرى بعد الاستخدام (منع إعادة الاستخدام)
  const qrCheckAgain = verifyQr(created.qr_token);
  assert.strictEqual(qrCheckAgain.valid, false, 'يجب ألا يكون الرمز صالحاً للدخول مرة أخرى');
  assert.strictEqual(qrCheckAgain.status, 'ALREADY_USED', 'يجب أن تكون الحالة ALREADY_USED');
  console.log('✓ اختبار 7: تسجيل الدخول ومنع تكرار استخدام QR ناجح');

  // 8. فحص إلغاء الحجز (لموعد قادم في الغد متجاوز لشرط الساعتين)
  const tomorrowSlot = db.appointments.find(a => {
    return a.date > now.toISOString().split('T')[0] && (a.capacity - (a.booked_count || 0)) >= 1 && a.is_active;
  });
  assert(tomorrowSlot, 'يجب العثور على موعد في الغد لاختبار الإلغاء');

  const anotherBooking = await createBooking({
    appointment_id: tomorrowSlot.id,
    full_name: 'طارق عبدالكريم',
    phone: '0577777777',
    national_id: '1555555555',
    persons_count: 1
  });

  const cancelled = cancelBooking(anotherBooking.id, 'الزائر');
  assert.strictEqual(cancelled.status, 'CANCELLED', 'يجب أن تكون الحالة CANCELLED');

  // فحص مسح الحجز الملغى
  const qrCheckCancelled = verifyQr(anotherBooking.qr_token);
  assert.strictEqual(qrCheckCancelled.valid, false);
  assert.strictEqual(qrCheckCancelled.status, 'CANCELLED', 'يجب إظهار أن الحجز ملغى');
  console.log('✓ اختبار 8: إلغاء الحجز وإبطال صلاحية الرمز واستعادة المقعد ناجح');

  console.log('=======================================================');
  console.log('🎉 جميع اختبارات منطق الأعمال والأمان وقاعدة البيانات نجحت بنسبة 100%!');
  console.log('=======================================================');
}

runTests().catch(err => {
  console.error('❌ فشل أحد الاختبارات:', err);
  process.exit(1);
});
